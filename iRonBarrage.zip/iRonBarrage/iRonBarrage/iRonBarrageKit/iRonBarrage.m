//
//  iRonBarrage.m
//  iRonBarrage
//
//  Created by iRonCheng on 2017/10/8.
//  Copyright © 2017年 iRonCheng. All rights reserved.
//

#import "iRonBarrage.h"
#import "iRonBarrageCell.h"

#define Weakself __weak typeof(self) weakSelf = self

@interface iRonBarrage ()

@property (assign, nonatomic) iRonBarrageStatusType currentStatus;

@property (strong, nonatomic) NSMutableArray *cachePool;

@property (strong, nonatomic) NSMutableArray *barrageScene;

@property (strong, nonatomic) NSTimer *timer;

@end

@implementation iRonBarrage

+ (instancetype)shareInstance
{
    static iRonBarrage *barrage = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        barrage = [[iRonBarrage alloc] init];
    });
    
    return barrage;
}

#pragma mark - System Cycle

- (instancetype)init
{
    self = [super init];
    if (self) {
        /* 
         * 默认移动速度
         * 默认初始速度
         */
        _scrollSpeed = iRonBarrageDisplaySpeedTypeDefault;
        _displayLocation = iRonBarrageDisplayLocationTypeDefault;
        _cachePool = [NSMutableArray array];
        _barrageScene = [NSMutableArray array];
    }
    return self;
}

//- (NSMutableArray *)barrageCache {
//    return _cachePool;
//}
//
//- (NSMutableArray<KYBarrageScene *> *)barrageScenes {
//    return _barrageScene;
//}

- (void)dealloc {
    if ([_timer isValid]){
        [_timer invalidate];
        _timer = nil;
    }
    
    if (_cachePool.count > 0) {
        [_cachePool removeAllObjects];
    }
    
    if (_barrageScene.count > 0) {
        [_barrageScene removeAllObjects];
    }
    
}

#pragma mark - Setter

- (void)setRefreshInterval:(NSTimeInterval)refreshInterval {
    _refreshInterval = refreshInterval;
    _timer = [NSTimer scheduledTimerWithTimeInterval:_refreshInterval target:self selector:@selector(buildBarrageScene) userInfo:nil repeats:true];
    [_timer setFireDate:[NSDate distantFuture]];
}


#pragma mark - Public Methods

//Take the initiative to obtain barrage
- (void)startScroll
{
    /* 定时器开始计时 */
    [_timer setFireDate:[NSDate date]];
}

//active receiving a barrage of data
/* data's type is ` KYBarrageModel ` or ` NSArray <KYBarrageModel *> `*/
- (void)showBarrageWithDataSource:(id)data
{
    if (!data) {
        return;
    }
    [self showWithData:data];
}

// pause or resume barrage
- (void)pauseScroll
{
    if (_currentStatus == iRonBarrageStatusTypeClose) {
        [self startScroll];
        return;
    }
    if (_currentStatus == iRonBarrageStatusTypeNormal) {
        //On the screen the barrage is suspended, and stop acquiring new barrage
        [_timer setFireDate:[NSDate distantFuture]];
        
        /* 遍历所有的子元素 */
        [self.barrageScene enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            iRonBarrageCell *scene = obj;
            [scene pause];
        }];
        _currentStatus = iRonBarrageStatusTypePause;
    } else if (_currentStatus == iRonBarrageStatusTypePause) {
        //The current barrage on the screen to start rolling, and to obtain a new barrage
        [_timer setFireDate:[NSDate date]];
        [self.barrageScene enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            iRonBarrageCell *scene = obj;
            [scene resume];
        }];
        _currentStatus = iRonBarrageStatusTypeNormal;
    }
}

// close barrage
- (void)closeBarrage
{
    if (_currentStatus == iRonBarrageStatusTypeNormal || _currentStatus == iRonBarrageStatusTypePause)  {
        _currentStatus = iRonBarrageStatusTypeClose;
        // On the screen the current barrage delete, and stop acquiring new barrage
        [_timer setFireDate:[NSDate distantFuture]];
        
        [self.barrageScene enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            iRonBarrageCell *scene = obj;
            [scene close];
        }];
    }
    //    }else if (_currentStatus == KYBarrageStatusTypeClose || _currentStatus == KYBarrageStatusTypePause) {
    //        _currentStatus = KYBarrageStatusTypeNormal;
    //        [_timer setFireDate:[NSDate date]];
    //    }
}

// Prevent memory leaks
- (void)toDealloc {
    
    if ([_timer isValid]){
        [_timer invalidate];
        _timer = nil;
    }
    
    if (_cachePool.count > 0) {
        [_cachePool removeAllObjects];
    }
    
    if (_barrageScene.count > 0) {
        [_barrageScene removeAllObjects];
    }
    
}

// Receive memory warning, can remove a barrage of buffer pool, the buffer pool can also remove half
- (void)didReceiveMemoryWarning {
    switch (_memoryMode) {
        case iRonBarrageMemoryWarningModeHalf:
            [self cleanHalfCache];
            break;
        case iRonBarrageMemoryWarningModeAll:
            [self cleanAllCache];
            break;
        default:
            break;
    }
}

#pragma mark - Privated Method

- (void)buildBarrageScene {
    /* build barrage model */
    if (![_dataSource  respondsToSelector:@selector(dataSourceForTheBarrage:)]) {
        return;
    }
    id data = [_dataSource dataSourceForTheBarrage:self];
    
    if (!data) {
        return;
    }
    [self showWithData:data];
}

/* data有两种格式：单个的Model或Model组成的array */
- (void)showWithData:(id)data {
    /*
     1. determine receiver's type
     2. determine build a new scene OR Taken from the buffer pool inside
     */
    _currentStatus = iRonBarrageStatusTypeNormal;
    @autoreleasepool {
        dispatch_async(dispatch_get_main_queue(), ^{
            if ([data isKindOfClass:[iRonBarrageModel class]]) {
                //only a KYBarrageModel
                iRonBarrageModel *model = data;
                model = [self sync_BarrageManagerConfigure:model];
                //Check whether the buffer pool is empty.
                if (_cachePool.count < 1) {
                    // nil
                    iRonBarrageCell *cell = [[iRonBarrageCell alloc] initWithFrame:CGRectZero Model:model];
                    [_barrageScene addObject:cell];
                    [_showingView addSubview:cell];
                    Weakself;
                    cell.animationDidStopBlock = ^(iRonBarrageCell *cell_){
                        
                        [weakSelf.cachePool addObject:cell_];
                        
                        [weakSelf.barrageScene removeObject:cell_];
                        [cell_ removeFromSuperview];
                    };
                    [cell scroll];
                    
                }else {
                    /*
                     *  注意：这里从缓存池拿出来的cell，都有个block，结束时会从父视图移除，再次加入缓存池
                     */
                    //From the buffer pool to Scene, it will be removed from the buffer pool
                    iRonBarrageCell *cell =  _cachePool.firstObject;
                    [_barrageScene addObject:cell];
                    /* 从缓存池删掉 */
                    [_cachePool removeObjectAtIndex:0];
                    /* 从缓存池里面拿出来的cell，要刷新model */
                    cell.model = model;
                    
                    [_showingView addSubview:cell];
                    [cell scroll];
                }
            }else {
                // more than one barrage
                NSArray <iRonBarrageModel *> *modelArray = data;
                [modelArray enumerateObjectsUsingBlock:^(iRonBarrageModel * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                    iRonBarrageModel *model = [self sync_BarrageManagerConfigure:obj];
                    //Check whether the buffer pool is empty.
                    if (_cachePool.count < 1) {
                        // nil
                        iRonBarrageCell *scene = [[iRonBarrageCell alloc] initWithFrame:CGRectZero Model:model];
                        [_barrageScene addObject:scene];
                        [_showingView addSubview:scene];
                        Weakself;
                        scene.animationDidStopBlock = ^(iRonBarrageCell *scene_){
                            [weakSelf.cachePool addObject:scene_];
                            [weakSelf.barrageScene removeObject:scene_];
                            [scene_ removeFromSuperview];
                        };
                        [scene scroll];
                        
                    }else {
                        //From the buffer pool to Scene, it will be removed from the buffer pool
                        
                        iRonBarrageCell *scene =  _cachePool.firstObject;
                        [_barrageScene addObject:scene];
                        [_cachePool removeObjectAtIndex:0];
                        scene.model = model;
                        
                        [_showingView addSubview:scene];
                        [scene scroll];
                    }
                }];
            }
        });
    }
}

/* 同步当前的model的部分属性:速度、方向、showView */
- (iRonBarrageModel *) sync_BarrageManagerConfigure:(iRonBarrageModel *)model {
    model.speed = _scrollSpeed;
    model.direction = _scrollDirection;
    model.showView = _showingView;
    return model;
}

/* 当内存警告时，删除部分的缓存 */
- (void)cleanHalfCache {
    NSRange range = NSMakeRange(0, _cachePool.count / 2);
    [_cachePool removeObjectsInRange:range];
}

- (void)cleanAllCache {
    [_cachePool removeAllObjects];
}


@end
