//
//  iRonBarrageModel.h
//  iRonBarrage
//
//  Created by iRonCheng on 2017/10/8.
//  Copyright © 2017年 iRonCheng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "iRonBarrageEnum.h"
#import "iRonBarrageUserModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface iRonBarrageModel : NSObject


//MARK: Model

// barrage's id
@property (nonatomic, assign) NSInteger numberID;

//  barrage's time
@property (nonatomic, strong) NSString *time;

// barrage's type
@property (nonatomic, assign) iRonBarrageDisplayType barrageType;

// barrage's speed
@property (nonatomic, assign) iRonBarrageDisplaySpeedType speed;

// barrage's direction
@property (nonatomic, assign) iRonBarrageScrollDirection direction;

// barage's location
@property (nonatomic, assign) iRonBarrageDisplayLocationType displayLocation;

//  barrage's superView
@property (nonatomic, weak) UIView *showView;

// barrage's content
@property (nonatomic, strong, nonnull) NSMutableAttributedString *message;

// barrage's author
@property (nonatomic, strong, nullable) id author;

// barrage's user
@property (nonatomic, strong) iRonBarrageUserModel *barrageUser;

// goal object
@property (nonatomic, strong, nullable) id object;

//KYBarrageDisplayTypeImage and KYBarrageDisplayTypeVote need to set height
@property (nonatomic, assign) float ky_hight;

// barrage's textfont
@property (nonatomic, copy) UIFont *font;

// barrage's textColor
@property (nonatomic, copy) UIColor *textColor;

//MARK: Barrage initialization method

/**
 init  KYBarrageModel
 
 @param numID barrage's id
 @param message barrage's content
 @param author barrage's author
 @param object goal object
 @return init  KYBarrageModel
 */
- (instancetype)initWithNumberID:(NSInteger)numID BarrageContent:(NSMutableAttributedString *)message Author:(nullable id)author Object:(nullable id)object;
/**
 init  KYBarrageModel
 
 @param numID barrage's id
 @param message barrage's content
 @return init  KYBarrageModel
 */
- (instancetype)initWithNumberID:(NSInteger)numID BarrageContent:(NSMutableAttributedString *)message;

/**
 init  KYBarrageModel
 
 @param message barrage's content
 @return init  KYBarrageModel
 */
- (instancetype)initWithBarrageContent:(NSMutableAttributedString *)message;

@end

NS_ASSUME_NONNULL_END
