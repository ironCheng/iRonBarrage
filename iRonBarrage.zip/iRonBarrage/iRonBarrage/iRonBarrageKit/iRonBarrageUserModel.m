//
//  iRonBarrageUserModel.m
//  iRonBarrage
//
//  Created by iRonCheng on 2017/10/8.
//  Copyright © 2017年 iRonCheng. All rights reserved.
//

#import "iRonBarrageUserModel.h"

@implementation iRonBarrageUserModel

@end
