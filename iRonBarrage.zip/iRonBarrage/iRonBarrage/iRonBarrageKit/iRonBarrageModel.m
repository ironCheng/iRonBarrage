//
//  iRonBarrageModel.m
//  iRonBarrage
//
//  Created by iRonCheng on 2017/10/8.
//  Copyright © 2017年 iRonCheng. All rights reserved.
//

#import "iRonBarrageModel.h"


@implementation iRonBarrageModel

#pragma mark - Init

- (instancetype)init {
    if (self = [super init]) {
        self.numberID = 0;
        self.message = [[NSMutableAttributedString alloc] initWithString:@""];
        self.author = nil;
        self.object = nil;
        
    }
    return self;
}

- (instancetype)initWithNumberID:(NSInteger)numID BarrageContent:(NSMutableAttributedString *)message Author:(nullable id)author Object:(nullable id)object {
    iRonBarrageModel *model = [[iRonBarrageModel alloc] init];
    model.numberID = numID;
    model.message = message;
    model.author = author;
    model.object = object;
    
    return model;
}

- (instancetype)initWithNumberID:(NSInteger)numID BarrageContent:(NSMutableAttributedString *)message {
    return [self initWithNumberID:numID BarrageContent:message Author:nil Object:nil];
}

- (instancetype)initWithBarrageContent:(NSMutableAttributedString *)message {
    return [self initWithNumberID:0 BarrageContent:message];
}

@end
