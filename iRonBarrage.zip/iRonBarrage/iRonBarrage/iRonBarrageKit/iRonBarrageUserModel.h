//
//  iRonBarrageUserModel.h
//  iRonBarrage
//
//  Created by iRonCheng on 2017/10/8.
//  Copyright © 2017年 iRonCheng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface iRonBarrageUserModel : NSObject

@property (nonatomic, assign) long userId;
@property (nonatomic, copy) NSString *name;
@property (nonatomic, strong) NSString *txt;
@property (nonatomic, copy) NSString *url;
@property (nonatomic, assign) int vip;
@property (nonatomic, assign) int vipFrom;

@end
