//
//  iRonBarrageCell.h
//  iRonBarrage
//
//  Created by iRonCheng on 2017/10/8.
//  Copyright © 2017年 iRonCheng. All rights reserved.
//

#import <UIKit/UIKit.h>
@class iRonBarrageCell;
@class iRonBarrageModel;

typedef void (^AnimationDidStopBlock) (iRonBarrageCell *cell);

@interface iRonBarrageCell : UIView <CAAnimationDelegate>

@property (nonatomic, copy) iRonBarrageModel *model;

@property (nonatomic, strong) UILabel *titleLabel;

@property (nonatomic, strong) UIButton *voteButton;

@property (nonatomic, strong) UIImageView *imageView;

@property (nonatomic, copy) AnimationDidStopBlock animationDidStopBlock;


- (instancetype)initWithFrame:(CGRect)frame Model:(iRonBarrageModel *)model;

- (void)scroll;

- (void)pause;

- (void)resume;

- (void)close;

@end
