//
//  iRonBarrage.h
//  iRonBarrage
//
//  Created by iRonCheng on 2017/10/8.
//  Copyright © 2017年 iRonCheng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "iRonBarrageModel.h"

@class iRonBarrage;


@protocol iRonBarrageDataSource <NSObject>

@required

- (id)dataSourceForTheBarrage:(iRonBarrage *)barrage;

@end


@interface iRonBarrage : NSObject


+ (instancetype)shareInstance;

@property (nonatomic, weak) id <iRonBarrageDataSource> dataSource;

// the view of show barrage
@property (nonatomic, weak) UIView *showingView;

@property (nonatomic, assign) NSInteger scrollSpeed;

// get barrages on time,
@property (nonatomic, assign) NSTimeInterval refreshInterval;

@property (nonatomic, assign) NSInteger displayLocation;

@property (nonatomic, assign) NSInteger scrollDirection;

// Text limited length
@property (nonatomic, assign) NSInteger textLengthLimit;

// Clear policy for receiving memory warning
@property (nonatomic, assign) NSInteger memoryMode;


#pragma mark - Public Methods

//Take the initiative to obtain barrage
- (void)startScroll;

//active receiving a barrage of data
/* data's type is ` KYBarrageModel ` or ` NSArray <KYBarrageModel *> `*/
- (void)showBarrageWithDataSource:(id)data;

// pause or resume barrage
- (void)pauseScroll;

// close barrage
- (void)closeBarrage;

// Receive memory warning, can remove a barrage of buffer pool, the buffer pool can also remove half
- (void)didReceiveMemoryWarning;

// Prevent memory leaks
- (void)toDealloc;

@end
