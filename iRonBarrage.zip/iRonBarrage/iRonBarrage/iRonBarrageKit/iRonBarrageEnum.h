//
//  iRonBarrageEnum.h
//  iRonBarrage
//
//  Created by iRonCheng on 2017/10/8.
//  Copyright © 2017年 iRonCheng. All rights reserved.
//

#ifndef iRonBarrageEnum_h
#define iRonBarrageEnum_h

typedef NS_ENUM(NSInteger, iRonBarrageStatusType) {
    iRonBarrageStatusTypeNormal = 0,
    iRonBarrageStatusTypePause,
    iRonBarrageStatusTypeClose,
};

// scroll speed of barrage,in seconds
typedef NS_ENUM(NSInteger, iRonBarrageDisplaySpeedType) {
    iRonBarrageDisplaySpeedTypeDefault = 10,
    iRonBarrageDisplaySpeedTypeFast = 20,
    iRonBarrageDisplaySpeedTypeFaster = 40,
    iRonBarrageDisplaySpeedTypeMostFast = 60,
};

//  The direction of the rolling barrage
typedef NS_ENUM(NSInteger, iRonBarrageScrollDirection) {
    iRonBarrageScrollDirectRightToLeft = 0,     /*  <<<<<   */
    iRonBarrageScrollDirectLeftToRight = 1,     /*  >>>>>   */
    iRonBarrageScrollDirectBottomToTop = 2,     /*  ↑↑↑↑   */
    iRonBarrageScrollDirectTopToBottom = 3,     /*  ↓↓↓↓   */
};


// location of barrage, `default` is global page
typedef NS_ENUM(NSInteger, iRonBarrageDisplayLocationType) {
    iRonBarrageDisplayLocationTypeDefault = 0,
    iRonBarrageDisplayLocationTypeTop = 1,
    iRonBarrageDisplayLocationTypeCenter = 2,
    iRonBarrageDisplayLocationTypeBottom = 3,
    iRonBarrageDisplayLocationTypeHidden,
};

//  type of barrage
typedef NS_ENUM(NSInteger, iRonBarrageDisplayType) {
    iRonBarrageDisplayTypeDefault = 0,  /* only text  */
    iRonBarrageDisplayTypeVote,         /* text and vote */
    iRonBarrageDisplayTypeImage,        /* text and image */
    iRonBarrageDisplayTypeCustomView,   /* Custom View  */
    iRonBarrageDisplayTypeOther,        /* other        */
};

// Clear policy for receiving memory warning
typedef NS_ENUM(NSInteger, iRonBarrageMemoryWarningMode) {
    iRonBarrageMemoryWarningModeHalf = 0,  //Clear hal
    iRonBarrageMemoryWarningModeAll,       //Clear ALL
};



#endif /* iRonBarrageEnum_h */
