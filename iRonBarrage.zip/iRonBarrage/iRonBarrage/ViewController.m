//
//  ViewController.m
//  iRonBarrage
//
//  Created by iRonCheng on 2017/10/8.
//  Copyright © 2017年 iRonCheng. All rights reserved.
//

#import "ViewController.h"
#import "iRonBarrage.h"

#define random(r, g, b, a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)/255.0]

#define RandomColor random(arc4random_uniform(256), arc4random_uniform(256), arc4random_uniform(256), arc4random_uniform(256))


@interface ViewController () <iRonBarrageDataSource>

@property (strong, nonatomic) iRonBarrage *manager;

@property (nonatomic, strong) UITextField *textField;
@property (nonatomic, strong) UIButton *sendBtn;

@property (nonatomic, strong) NSMutableArray *talkPool;

@property (nonatomic, strong) NSString *idSting;
@property (nonatomic, strong) NSString *nameString;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    _manager = [iRonBarrage shareInstance];
    _manager.showingView = self.view;
    _manager.scrollSpeed = 90;
    _manager.refreshInterval = 0.5;
    _manager.displayLocation = iRonBarrageDisplayLocationTypeTop;
    
    _manager.dataSource = self;
    [_manager startScroll];
    
    
    UIButton *sendBtn = [[UIButton alloc] initWithFrame:CGRectMake(self.view.frame.size.width/2-100, self.view.frame.size.height-100, 200, 50)];
    [sendBtn setTitle:@"sendBarrage" forState:UIControlStateNormal];
    [sendBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [sendBtn addTarget:self action:@selector(sendABarrage) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:sendBtn];
}

/* manual 手动发送 */
- (void)sendABarrage
{
    int a = arc4random() % 100000;
    NSString *str = [NSString stringWithFormat:@"(手动发送)manual coming %d ",a];
    
    NSMutableAttributedString *attr = [[NSMutableAttributedString alloc] initWithString:str];
    [attr addAttribute:NSForegroundColorAttributeName value:RandomColor range:NSMakeRange(0, str.length)];
    
    iRonBarrageModel *m = [[iRonBarrageModel alloc] initWithBarrageContent:attr];
    m.displayLocation       =  iRonBarrageDisplayLocationTypeTop;
    m.direction       = _manager.scrollDirection;
    //    m.barrageType = KYBarrageDisplayTypeImage;
    [_manager showBarrageWithDataSource:m]; // Scroll Barrage
    
}

#pragma mark - DataSource

- (id)dataSourceForTheBarrage:(iRonBarrage *)barrage
{
    
    int a = arc4random() % 10000;
    NSString *str = [NSString stringWithFormat:@"%d",a];
    if (self.talkPool.count) {
        str = self.talkPool.firstObject;
        [self.talkPool removeObjectAtIndex:0];
    }
    
    NSMutableAttributedString *attr = [[NSMutableAttributedString alloc] initWithString:str];
    [attr addAttribute:NSForegroundColorAttributeName value:RandomColor range:NSMakeRange(0, str.length)];
    
    iRonBarrageModel *m = [[iRonBarrageModel alloc] initWithBarrageContent:attr];
    m.displayLocation = _manager.displayLocation;
    m.direction       = _manager.scrollDirection;
    m.object = [UIImage imageNamed:[NSString stringWithFormat:@"digg_%d",arc4random() % 10]];
    return m;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
